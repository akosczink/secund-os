# How to add this pack to GitHub
1) Create repo `secund-os` (public).
2) Upload this ZIP and extract at repository root OR commit files as-is under `/ip/` folder.
3) Commit message: "chore(ip): add SECUND_PROTECTION_PACK v1.0".
4) Tag the commit: `git tag -a ip-baseline-v1 -m "IP baseline v1"` then push tags.
5) Create a GitHub Release named "IP Baseline v1" and attach this ZIP for immutability.
