# SECUND Metrics Baseline (Public Snapshot)
RBB (Reality–Believability Balance): ≥9.2 (target ≥9.35)
tofu (fabrication tolerance): 0 (strict)
SR (Stability Ratio): ≥0.25
Release QA gates: correctness/recency, runnable code, SEO/Lighthouse ≥95 mobile when web assets are shipped.
