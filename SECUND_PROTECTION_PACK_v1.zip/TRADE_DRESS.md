# Trade Dress / Look & Feel (Baseline)
- Colorway: black/charcoal backgrounds; gold/white typography accents.
- Typography: Playfair (serif headline) + Roboto (body).
- Layout: safe‑zone cards, premium gradient panels, top‑right CTA chip where applicable.
- Iconography: subtle hourglass motif.
- Copy tone: premium, clear, no emoji in public sales copy (unless specified campaigns).
